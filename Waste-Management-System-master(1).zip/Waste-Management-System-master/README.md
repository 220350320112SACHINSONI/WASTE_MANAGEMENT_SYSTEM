# Waste-Management-System
The system uses stack and queue data structures to imitate the actions of garbage cans and trucks.
